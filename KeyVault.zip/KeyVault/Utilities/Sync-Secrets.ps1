# Cmdlets to synchronise the common secrets in the CCC Key Vaults
# with those in the ccc-mgmt-kv Key Vault.

function Compare-Secrets {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $KeyVaultName,

        [Parameter(Mandatory = $true)]
        [PSCustomObject[]]
        $SourceSecrets
    )

    Write-Information -MessageData "`nINFO --- Compare source secrets with the secrets in Key Vault '$KeyVaultName'." -InformationAction Continue

    $subscriptionAlias = Get-CccSubscriptionAlias
    $comparison = @()
    foreach ($sourceSecret in $SourceSecrets) {
        if ($subscriptionAlias -notmatch $sourceSecret.Subscription) {
            Continue
        }

        Write-Information -MessageData "INFO --- Get secret '$($sourceSecret.SecretName)' from Key Vault '$KeyVaultName'." -InformationAction Continue
        $secret = Get-AzKeyVaultSecret -Name $sourceSecret.SecretName -VaultName $KeyVaultName
        if ($secret) {
            $secretText = Get-SecretText -SecretValue $secret.SecretValue
            $comparison += [PSCustomObject]@{
                SecretName    = $sourceSecret.SecretName
                Exists        = $true
                SecretSame    = $sourceSecret.SecretText -eq $secretText
                ExpiresSame   = $sourceSecret.Expires -eq $secret.Expires
                ExpiresMgmt   = $sourceSecret.Expires
                ExpiresTarget = $secret.Expires
            }
        }
        else {
            $comparison += [PSCustomObject]@{
                SecretName   = $sourceSecret.SecretName
                Exists       = $false
                SecretsSame  = $false
                ExpireSame   = $false
                ExpireMgmt   = $null
                ExpireTarget = $null
            }
        }
    }

    $report = $comparison.GetEnumerator() | Sort-Object -Property SecretName
    $report | Format-Table -AutoSize | Out-String | ForEach-Object { Write-Information -MessageData $_ -InformationAction Continue }
}

function Get-SynchronisationSet {
    [CmdletBinding()]
    param ()

    # Regular expressions to match the subscriptions
    $all = '^(vdc\d?|cctv|cmg|eng|ijmprod|vdi\d?|vvf|vwi\d?)\d\d$'
    $eng = '^eng01$'
    $landingZone = '^(vdc\d?|cctv|cmg|ijmprod|\d?|vvf|vwi\d?)\d\d$'

    # Synchronisation set contains the name of the secrets that should be synchronised.
    # The name of the secret in the management Key Vault is used as the key.
    # Each entry contains a:
    # - SecretName
    #   The name of the secret in the destination subscription.
    #   When not specified it will be the same as the name of the secret in the management Key Vault.
    # - Subscription
    #   A regular expression to match the destination subscription.
    $synchronisationSet = [ordered]@{}
    $synchronisationSet['ARMS-AutoServiceAccountMan-Username'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['ARMS-AutoServiceAccountMan-Password'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['CCC-AADS-VSTS-Admin-PAT'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['CCC-tse-enterprise-DeploymentGroupAdmin-PAT'] = @{ SecretName = $null; Subscription = $landingZone }
    $synchronisationSet['CCCAutomationSPPassword'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['CCCAutomationSPUserName'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['DomainJoinPassword'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['DomainJoinUserName'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['infra01-mail-p-la-url'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['infra01tsenemltplsa01-Key'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['OfficeUserName'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['OfficeUserNameSecret'] = @{ SecretName = $null; Subscription = $all }
    $synchronisationSet['OMSWorkSpaceID' ] = @{ SecretName = $null; Subscription = $landingZone }
    $synchronisationSet['OMSWorkSpaceKey'] = @{ SecretName = $null; Subscription = $landingZone }

    return $synchronisationSet
}

function Get-Secrets {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $KeyVaultName
    )

    Write-SynchronisationSet

    Write-Information -MessageData "INFO --- Get source secrets from Key Vault '$KeyVaultName'." -InformationAction Continue

    $secrets = @()
    $synchronisationSet = Get-SynchronisationSet
    foreach ($name in $synchronisationSet.Keys) {
        Write-Information -MessageData "INFO --- Get secret '$name' from Key Vault '$KeyVaultName'." -InformationAction Continue
        $secret = Get-AzKeyVaultSecret -Name $name -VaultName $KeyVaultName
        if (-not $secret) {
            Write-Warning -Message "WARNING --- Secret '$name' not found in Key Vault '$KeyVaultName'." -WarningAction Continue
        }
        else {
            $item = $synchronisationSet[$name]
            $secretName = $item.SecretName
            if (-not $secretName) {
                $secretName = $name
            }
            $secrets += [PSCustomObject]@{
                SecretName   = $secretName
                SecretText   = Get-SecretText -SecretValue $secret.SecretValue
                Subscription = $item.Subscription
                Expires      = $secret.Expires
            }
        }
    }

    return $secrets
}

function Get-SecretText {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Security.SecureString]
        $SecretValue
    )

    $secretText = ''
    $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecretValue)
    try {
        $secretText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
    }

    return $secretText
}

function Invoke-SyncSecrets {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [switch]
        $WhatIf
    )

    Write-Information -MessageData "INFO --- Start script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue

    # Set ps_modules directory.
    if (-not $PS_MODULES_DIRECTORY) {
        $azureRoot = Split-Path -Path $PSScriptRoot -Parent | Split-Path -Parent | Split-Path -Parent
        New-Variable -Name 'PS_MODULES_DIRECTORY' -Option Constant -Scope Global -Value (Join-Path -Path $azureRoot -ChildPath 'Nuget' | Join-Path -ChildPath 'ps_modules')
    }

    # Load the bootstrap functions and import modules AZ and CCC.
    Import-Module -Name (Join-Path -Path $PS_MODULES_DIRECTORY -ChildPath 'CccBootstrap') -Force
    Import-AzModule
    Import-CccModule

    Sync-Secrets -WhatIf:$WhatIf

    Write-Information -MessageData "INFO --- End script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue
}

function Sync-Secrets {
    [CmdletBinding()]
    param (
        [Parameter()]
        [switch]
        $WhatIf
    )

    $ErrorActionPreference = 'Stop'

    $subscriptions = @(
        'TSE AZ CCTV01'
        'TSE AZ CMG01'
        'TSE AZ Eng01'
        'TSE AZ IJMPROD01'
        'TSE AZ VDC01'
        'TSE AZ VDC02'
        'TSE AZ VDC03'
        'TSE AZ VDC04'
        'TSE AZ VDC101'
        'TSE AZ VDI01'
        'TSE AZ VVF01'
        'TSE AZ VWI01'
        'TSE AZ VWI101'
    )

    $secrets = Get-Secrets -KeyVaultName 'ccc-mgmt-kv'
    foreach ($subscription in $subscriptions) {
        Write-Information -MessageData "`nINFO --- Synchronise secrets in subscription '$subscription'." -InformationAction Continue
        $context = Connect-CccServiceAccount -Subscription $subscription
        try {
            $keyVaultName = Get-CccKeyVaultName
            Compare-Secrets -KeyVaultName $keyVaultName -SourceSecrets $secrets
            Update-Secrets -KeyVaultName $keyVaultName -SourceSecrets $secrets -WhatIf:$WhatIf
        }
        finally {
            Disconnect-CccServiceAccount -Context $context
        }
    }
}

function Update-Secrets {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $KeyVaultName,

        [Parameter(Mandatory = $true)]
        [PSCustomObject[]]
        $SourceSecrets,

        [switch]
        [Parameter( Mandatory = $false)]
        $WhatIf
    )

    Write-Information -MessageData "INFO --- Update secrets in Key Vault '$KeyVaultName'." -InformationAction Continue

    $subscriptionAlias = Get-CccSubscriptionAlias
    foreach ($sourceSecret in $SourceSecrets) {
        if ($subscriptionAlias -notmatch $sourceSecret.Subscription) {
            Continue
        }

        $update = $true
        Write-Information -MessageData "`nINFO --- Get secret '$($sourceSecret.SecretName)' from Key Vault '$KeyVaultName'." -InformationAction Continue
        $secret = Get-AzKeyVaultSecret -Name $sourceSecret.SecretName -VaultName $KeyVaultName
        if ($secret) {
            # It exists, check if expiration date or secret is different.
            $secretText = Get-SecretText -SecretValue $secret.SecretValue
            $update = $sourceSecret.Expires -ne $secret.Expires -or $sourceSecret.SecretText -ne $secretText
        }

        if ($update) {
            # Secret does not exist or differs from the source secret.
            Write-Information -MessageData "INFO --- Set secret '$($sourceSecret.SecretName)' in Key Vault '$KeyVaultName' with expiration date $($sourceSecret.Expires)." -InformationAction Continue
            $secretValue = ConvertTo-SecureString -String $sourceSecret.SecretText -AsPlainText -Force
            Set-AzKeyVaultSecret -Expires $sourceSecret.Expires -Name $sourceSecret.SecretName -SecretValue $secretValue -VaultName $KeyVaultName -WhatIf:$WhatIf
        }
        else {
            Write-Information -MessageData "INFO --- Secret '$($sourceSecret.SecretName)' in Key Vault '$KeyVaultName' is up to date." -InformationAction Continue
        }
    }
}

function Write-SynchronisationSet {
    [CmdletBinding()]
    param ()

    Write-Information -MessageData "`nINFO --- Overview of secrets to be synchronised:" -InformationAction Continue
    $synchronisationSet = Get-SynchronisationSet
    $c1 = @{label = 'Secret Name (mgmt)'; expression = { $_.Name } }
    $c2 = @{label = 'Secret Name (subscription)'; expression = { if ($_.Value.SecretName) { $_.Value.SecretName } else { $_.Name } } }
    $c3 = @{label = 'Subscription'; expression = { $_.Value.Subscription } }
    $synchronisationSet | Format-Table -Property $c1, $c2, $c3 -AutoSize | Out-String | ForEach-Object { Write-Information -MessageData $_ -InformationAction Continue }
}