function Remove-UnknownAccessPolicies{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "Resource group")]
        [string]
        $ResourceGroupName,

        [Parameter(Mandatory = $true, HelpMessage = "Keyvault target")]
        [string]
        $VaultName,

        [switch]
        [Parameter(HelpMessage = "Whether to execute for real")]
        $WhatIf
    )
    $KeyVault = Get-AzKeyvault -ResourceGroupName $ResourceGroupName -VaultName $VaultName
    if($KeyVault){
        $unknownObjects = ($keyVault.AccessPolicies | where-object {($_.DisplayName -eq "")}).Objectid
        foreach($objectid in $unknownObjects){
            Write-Information -MessageData "Remove AzKeyVaultAccessPolicy ObjectId $objectid of keyVaultName $KeyVaultName in ResourceGroupName $ResourceGroupName" -InformationAction Continue
            Remove-AzKeyVaultAccessPolicy -VaultName $KeyVault.VaultName -ResourceGroupName $KeyVault.ResourceGroupName -ObjectId $objectid -WhatIf:$WhatIf
        }
    }
}
