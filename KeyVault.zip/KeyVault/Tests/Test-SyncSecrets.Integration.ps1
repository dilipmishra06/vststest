function Initialize-TestEnvironment {
    Write-Information -MessageData 'INFO --- Initialize test environment.' -InformationAction Continue

    # Load the bootstrap functions.
    Import-Module -Name (Join-Path -Path $PS_MODULES_DIRECTORY -ChildPath 'CccBootstrap') -Force
    Import-AzModule
    Import-CccModule

    # Create dynamic function to retrieve service account
    . (Join-Path -Path $PS_MODULES_DIRECTORY -ChildPath 'CCC\Set-CccServiceAccountFunction.ps1')
}

function Test-SyncSecrets {
    $testWhatIf = $true

    Sync-Secrets -WhatIf:$testWhatIf
}

# Set default folder.
$here = $PSScriptRoot
Set-Location -Path $here

if (-not $PS_MODULES_DIRECTORY) {
    $azureRoot = Split-Path -Path $here -Parent | Split-Path -Parent | Split-Path -Parent
    New-Variable -Name PS_MODULES_DIRECTORY -Value (Join-Path -Path $azureRoot -ChildPath 'Nuget' | Join-Path -ChildPath 'ps_modules') -Option Constant -Scope Global
    Write-Information -MessageData "INFO --- PS_MODULES_DIRECTORY = $PS_MODULES_DIRECTORY" -InformationAction Continue
}

if (-not $testEnvironmentInitialized) {
    try {
        Initialize-TestEnvironment
        $testEnvironmentInitialized = $true
    }
    catch {
        $testEnvironmentInitialized = $false
    }
}

# Load script files.
. (Join-Path -Path $here -ChildPath '..\Utilities\Sync-Secrets.ps1')

$null = Set-AzContext -SubscriptionName 'TSE AZ Management'

Test-SyncSecrets