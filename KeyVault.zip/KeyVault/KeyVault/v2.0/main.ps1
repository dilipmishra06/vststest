<#
Following script creates, updates or removes a Key Vault.
#>

Trace-VstsEnteringInvocation $MyInvocation

Write-Information -MessageData 'INFO --- Starting Key Vault task.' -InformationAction Continue

# Set ps_modules directory
if (-not $PS_MODULES_DIRECTORY) {
    New-Variable `
        -Name 'PS_MODULES_DIRECTORY' `
        -Option Constant `
        -Scope Global `
        -Value (Join-Path -Path $PSScriptRoot -ChildPath 'ps_modules')
}

# Load the bootstrap functions.
Import-Module -Name (Join-Path -Path $PS_MODULES_DIRECTORY -ChildPath 'CccBootstrap') -Force

Initialize-CccAzureDevOpsExtension
Import-CccModule

# Get inputs
$action = Get-VstsInput -Name action

switch ($action) {
    'new' {
        $enabledForDeployment = Get-VstsInput -Name enabledForDeployment -AsBool
        $enabledForDiskEncryption = Get-VstsInput -Name enabledForDiskEncryption -AsBool
        $enabledForTemplateDeployment = Get-VstsInput -Name enabledForTemplateDeployment -AsBool
        $keyVaultPrefix = Get-VstsInput -Name keyVaultPrefix
        $location = Get-VstsInput -Name location
        $objectId = Get-VstsInput -Name objectId
        $resourceGroupName = Get-VstsInput -Name resourceGroupName
        $sku = Get-VstsInput -Name sku

        Write-Information -MessageData 'INFO --- Creating a Key Vault in a Resource Group' -InformationAction Continue
        Write-Information -MessageData 'INFO --- User variables are:' -InformationAction Continue
        Write-Information -MessageData "INFO --- enabledForDeployment:         $enabledForDeployment" -InformationAction Continue
        Write-Information -MessageData "INFO --- enabledForDiskEncryption:     $enabledForDiskEncryption" -InformationAction Continue
        Write-Information -MessageData "INFO --- enabledForTemplateDeployment: $enabledForTemplateDeployment" -InformationAction Continue
        Write-Information -MessageData "INFO --- keyVaultNamePrefix:           $keyVaultPrefix" -InformationAction Continue
        Write-Information -MessageData "INFO --- location:                     $location" -InformationAction Continue
        Write-Information -MessageData "INFO --- objectId:                     $objectId" -InformationAction Continue
        Write-Information -MessageData "INFO --- resourceGroupName:            $resourceGroupName" -InformationAction Continue
        Write-Information -MessageData "INFO --- sku:                          $sku" -InformationAction Continue

        # Load script file
        . (Join-Path -Path $PSScriptRoot -ChildPath 'Scripts\Internal.ps1')

        $selectedScenarioFilePath = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'Templates\keyvault.json'))
        $scriptFile = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'Scripts\New-KeyVault.ps1'))
        . $scriptFile `
            -EnabledForDeployment $enabledForDeployment `
            -EnabledForDiskEncryption $enabledForDiskEncryption `
            -EnabledForTemplateDeployment $enabledForTemplateDeployment `
            -KeyVaultNamePrefix $keyVaultPrefix `
            -Location $location `
            -ObjectId $objectId `
            -ResourceGroupName $resourceGroupName `
            -Sku $sku `
            -TemplateFile $selectedScenarioFilePath
        break
    }

    'update' {
        $objectId = Get-VstsInput -Name objectId
        $resourceGroupName = Get-VstsInput -Name resourceGroupName
        $keyVaultName = Get-VstsInput -Name keyVaultName

        Write-Information -MessageData 'INFO --- Updating a Key Vault in a Resource Group' -InformationAction Continue
        Write-Information -MessageData 'INFO --- User variables are:' -InformationAction Continue
        Write-Information -MessageData "INFO --- keyVaultName:      $keyVaultName" -InformationAction Continue
        Write-Information -MessageData "INFO --- objectId:          $objectId" -InformationAction Continue
        Write-Information -MessageData "INFO --- resourceGroupName: $resourceGroupName" -InformationAction Continue

        # Load script file
        . (Join-Path -Path $PSScriptRoot -ChildPath 'Scripts\Internal.ps1')

        $selectedScenarioFilePath = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'Templates\keyvault.json'))
        $scriptFile = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'Scripts\Update-KeyVault.ps1'))
        . $scriptFile `
            -KeyVaultName $keyVaultName `
            -ObjectId $objectId `
            -ResourceGroupName $resourceGroupName
        break
    }

    'remove' {
        $keyVaultName = Get-VstsInput -Name keyVaultName
        $resourceGroupName = Get-VstsInput -Name resourceGroupName

        Write-Information -MessageData 'INFO --- Removing a Key Vault from a Resource Group' -InformationAction Continue
        Write-Information -MessageData 'INFO --- User variables are:' -InformationAction Continue
        Write-Information -MessageData "INFO --- keyVaultName:      $keyVaultName" -InformationAction Continue
        Write-Information -MessageData "INFO --- resourceGroupName: $resourceGroupName" -InformationAction Continue


        $scriptFile = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'Scripts\Remove-KeyVault.ps1'))
        . $scriptFile `
            -KeyVaultName $keyVaultName `
            -ResourceGroupName $resourceGroupName
        break
    }
    default {
        throw "Unknow action '$action'"
    }
}

Write-Information -MessageData 'INFO --- End Key Vault task' -InformationAction Continue