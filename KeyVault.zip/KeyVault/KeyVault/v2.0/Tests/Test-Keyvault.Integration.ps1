function Initialize-TestEnvironment {
    # Load the bootstrap functions.
    Import-Module -Name (Join-Path -Path $PS_MODULES_DIRECTORY -ChildPath 'CccBootstrap') -Force

    Import-AzModule
    Import-Cccmodule

    # Create dynamic function to retrieve service account
    . (Join-Path -Path $PS_MODULES_DIRECTORY -ChildPath 'CCC\Set-CccServiceAccountFunction.ps1')
}

function Test-NewKeyvault {
    $enabledForDeployment = $true
    $enabledForDiskEncryption = $true
    $enabledForTemplateDeployment = $true
    $keyVaultPrefix = 'tstmv02'
    $location = ''
    $resourceGroupName = 'cccmv01-d-rg'
    $sku = 'Standard'

    $objectId = (Get-CccResourceGroupServicePrincipal -ResourceGroupName $resourceGroupName).id
    $templateFile = Join-Path -Path $here -ChildPath '..\Templates\Keyvault.json'

    . (Join-Path -Path $here -ChildPath '..\Scripts\Internal.ps1')
    $scriptFile = Join-Path -Path $here -ChildPath '..\Scripts\New-Keyvault.ps1'
    . $scriptFile `
        -EnabledForDeployment $enabledForDeployment `
        -EnabledForDiskEncryption $enabledForDiskEncryption `
        -EnabledForTemplateDeployment $enabledForTemplateDeployment `
        -KeyVaultNamePrefix $keyVaultPrefix `
        -Location $location `
        -ObjectId $objectId `
        -ResourceGroupName $resourceGroupName `
        -Sku $sku `
        -TemplateFile $templateFile
}

function Test-RemoveKeyvault {
    $keyvaultName = 'tstmv02-eng01-d-kv'
    $resourceGroupName = 'cccmv01-d-rg'
    $scriptFile = Join-Path -Path $here -ChildPath '..\Scripts\Remove-Keyvault.ps1'
    . $scriptFile `
        -KeyvaultName $KeyvaultName `
        -ResourceGroupName $resourceGroupName
}

function Test-UpdateKeyvault {
    $KeyvaultName = 'tstmv02-eng01-d-kv'
    $resourceGroupName = 'cccmv01-d-rg'
    $objectId = (Get-CccResourceGroupServicePrincipal -ResourceGroupName $resourceGroupName).id

    . (Join-Path -Path $here -ChildPath '..\Scripts\Internal.ps1')
    $scriptFile = Join-Path -Path $here -ChildPath '..\Scripts\Update-Keyvault.ps1'
    . $scriptFile `
        -KeyVaultName $keyVaultName `
        -ObjectId $objectId `
        -ResourceGroupName $resourceGroupName
}

# Set default folder.
$here = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
Set-Location -Path $here

if (-not $PS_MODULES_DIRECTORY) {
    $azureRoot = Split-Path -Path $here -Parent | Split-Path -Parent | Split-Path -Parent | Split-Path -Parent | Split-Path -Parent
    New-Variable -Name PS_MODULES_DIRECTORY -Value (Join-Path -Path $azureRoot -ChildPath 'Nuget' | Join-Path -ChildPath 'ps_modules') -Option Constant -Scope Global
    Write-Information -MessageData "INFO --- PS_MODULES_DIRECTORY = $PS_MODULES_DIRECTORY" -InformationAction Continue
}

if (-not $testEnvironmentInitialized) {
    Write-Information -MessageData 'INFO --- Initialize test environment' -InformationAction Continue
    try {
        Initialize-TestEnvironment
        $testEnvironmentInitialized = $true
    }
    catch {
        $testEnvironmentInitialized = $false
    }
}

#Test-NewKeyvault
#Test-UpdateKeyvault
Test-RemoveKeyvault