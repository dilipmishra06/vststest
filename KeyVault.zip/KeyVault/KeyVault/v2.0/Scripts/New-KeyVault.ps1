[CmdletBinding()]
Param (
    [Parameter(Mandatory = $true)]
    [bool]
    $EnabledForDeployment,

    [Parameter(Mandatory = $true)]
    [bool]
    $EnabledForDiskEncryption,

    [Parameter(Mandatory = $true)]
    [bool]
    $EnabledForTemplateDeployment,

    [Parameter(Mandatory = $true)]
    [ValidateLength(3, 12)]
    [ValidatePattern('^[a-zA-Z0-9-]+$')]
    [string]
    $KeyVaultNamePrefix,

    [Parameter(Mandatory = $false)]
    [ValidateSet(
        'northeurope',
        'westeurope',
        'uksouth',
        'ukwest',
        '')]
    [string]
    $Location,

    [Parameter(Mandatory = $false)]
    [string]
    $ObjectId,

    [Parameter(Mandatory = $true)]
    [ValidateLength(1, 90)]
    [ValidatePattern('^[-\w\._\(\)]+$')]
    [string]
    $ResourceGroupName,

    [Parameter(Mandatory = $false)]
    [ValidateSet('Standard', 'Premium')]
    [string]
    $Sku,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $TemplateFile
)

Write-Information -MessageData "INFO --- Start script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue

# In case of an error, display the error message and stop executing
$ErrorActionPreference = 'Stop'

# Verify Resource Group existence and get properties.
$resourceGroup = Get-CccResourceGroup -Name $ResourceGroupName
$ResourceGroupName = $resourceGroup.ResourceGroupName

# Generate Key Vault name.
$subscriptionAlias = Get-CccSubscriptionAlias
$environmentAlias = Get-CccEnvironmentAlias -ResourceGroupName $ResourceGroupName
if ($ResourceGroupName -eq 'infra01-p-rg') {
    $keyVaultName = "$KeyVaultNamePrefix-$subscriptionAlias-kv".ToLower()
}
else {
    $keyVaultName = "$KeyVaultNamePrefix-$subscriptionAlias-$environmentAlias-kv".ToLower()
}

Write-Information -MessageData "INFO --- Key Vault name is '$keyVaultName'." -InformationAction Continue

# Assert location
$Location = Assert-CccLocation -Location $Location -ResourceGroup $resourceGroup

# Get service principal of key rotation function
$context = Connect-CccServiceAccount -ActiveDirectory
try {
    $keyRotationServicePrincipalApplicationId = (Get-MgApplication -Filter ("DisplayName eq 'ccc01-keyrotation-fun-p-p-as--online-sp'")).AppId
}
finally {
    Disconnect-CccServiceAccount -Context $context
}

$templateParameterObject = @{
    enabledForDeployment                     = $EnabledForDeployment
    enabledForDiskEncryption                 = $EnabledForDiskEncryption
    enabledForTemplateDeployment             = $EnabledForTemplateDeployment
    keyRotationServicePrincipalApplicationId = $keyRotationServicePrincipalApplicationId
    keyVaultName                             = $keyVaultName
    location                                 = $Location
    sku                                      = $Sku
    webHookUrl                               = 'https://keyrotation.sd.online/api/AutomaticRotation'
}

Write-Information -MessageData 'INFO --- Start Key Vault deployment...' -InformationAction Continue
try {
    $result = Test-AzResourceGroupDeployment `
        -ResourceGroupName $ResourceGroupName `
        -TemplateFile $TemplateFile `
        -TemplateParameterObject $templateParameterObject

    $result = New-AzResourceGroupDeployment `
        -Mode Incremental `
        -Name ('KeyVault_' + (Get-Date).ToString('yyyyMMdd_HHmmss')) `
        -ResourceGroupName $ResourceGroupName `
        -TemplateFile $TemplateFile `
        -TemplateParameterObject $templateParameterObject
}
catch {
    Write-Information -MessageData 'INFO --- Key Vault deployment failed.' -InformationAction Continue
    throw
}

Write-Information -MessageData 'INFO --- End Key Vault deployment.' -InformationAction Continue

# Make deployment outputs available to downstream steps within the same job
Get-CccResourceGroupDeploymentOutputVariables -ResourceGroupDeployment $result | Set-CccAzurePipelineVariables

# Set Key Vault access policies for subscription service principal.
$vstsServicePrincipalName = Get-CccSubscriptionServicePrincipalName
$vstsServicePrincipalId = (Get-AzADServicePrincipal -DisplayName $vstsServicePrincipalname).Id
if (![string]::IsNullOrEmpty($vstsServicePrincipalId)) {
    Set-DefaultKeyVaultAccessPolicy `
        -KeyVaultName $keyVaultName `
        -ObjectId $vstsServicePrincipalId `
        -ObjectName $vstsServicePrincipalName `
        -ResourceGroupName $ResourceGroupName
}

# Set Key Vault access policies for resource group service principal.
if (($ObjectId -eq '$(ServicePrincipalId)') -or ([string]::IsNullOrEmpty($ObjectId))) {
    $resourceGroupServicePrincipal = Get-CccResourceGroupServicePrincipal -ResourceGroupName $resourceGroupName
}
if (![string]::IsNullOrEmpty($resourceGroupServicePrincipal)) {
    Set-DefaultKeyVaultAccessPolicy `
        -KeyVaultName $keyVaultName `
        -ObjectId $resourceGroupServicePrincipal.Id `
        -ObjectName $resourceGroupServicePrincipal.DisplayName `
        -ResourceGroupName $ResourceGroupName
}
else {
    Set-DefaultKeyVaultAccessPolicy `
        -KeyVaultName $keyVaultName `
        -ObjectId $ObjectId `
        -ResourceGroupName $ResourceGroupName
}

# Set Key Vault access policies for Active Directory group that is used for the resource group.
$aadGroup = Get-CccResourceGroupReaderGroup -ResourceGroupName $resourceGroupName
if (![string]::IsNullOrEmpty($aadGroup)) {
    Set-DefaultKeyVaultAccessPolicy `
        -KeyVaultName $keyVaultName `
        -ObjectId $aadGroup.ObjectId `
        -ObjectName $aadGroup.DisplayName `
        -ResourceGroupName $ResourceGroupName
}

Write-Information -MessageData "INFO --- End script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue