[CmdletBinding()]
Param
(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[a-zA-Z0-9-]+$')]
    [string]
    $KeyVaultName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]
    $ObjectId,

    [Parameter(Mandatory = $true)]
    [ValidateLength(1, 90)]
    [ValidatePattern('^[-\w\._\(\)]+$')]
    [string]
    $ResourceGroupName
)

Write-Information -MessageData "INFO --- Start script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue
# In case of an error, display the error message and stop executing
$ErrorActionPreference = 'Stop'

# Verify Resource Group existence and get properties.
$resourceGroup = Get-CccResourceGroup -Name $ResourceGroupName
$ResourceGroupName = $resourceGroup.ResourceGroupName

# Verify Key Vault existence and get its name.
$keyVault = Get-CccKeyVault -VaultName $KeyVaultName -ResourceGroupName $ResourceGroupName
$KeyVaultName = $KeyVault.VaultName

if (($ObjectId -eq '$(ServicePrincipalId)') -or ([string]::IsNullOrEmpty($ObjectId))) {
    $resourceGroupServicePrincipal = Get-CccResourceGroupServicePrincipal -ResourceGroupName $resourceGroupName
    $ObjectId = $resourceGroupServicePrincipal.Id
    $objectName = $resourceGroupServicePrincipal.DisplayName
}
else {
    # evaluate The object id can be of SPN, AD Group or AD User
    $objectName = (Get-AzADServicePrincipal -ObjectId $ObjectId).DisplayName
    if (![string]::IsNullOrEmpty($objectName)) {
        Write-Information -MessageData "INFO --- Azure service prinipal '$objectName' belonging to Object Id '$ObjectId' " -InformationAction Continue
    }
    if ([string]::IsNullOrEmpty($objectName)) {
        $objectName = (Get-AzADGroup -ObjectId $ObjectId).DisplayName
        if (![string]::IsNullOrEmpty($objectName)) {
            Write-Information -MessageData "INFO --- AD group '$objectName' belonging to Object Id '$ObjectId' was found" -InformationAction Continue
        }
    }
    if ([string]::IsNullOrEmpty($objectName)) {
        $objectName = (Get-AzADUser -ObjectId $ObjectId).UserPrincipalName
        if (![string]::IsNullOrEmpty($objectName)) {
            Write-Information -MessageData "INFO --- AD user '$objectName' belonging to Object Id '$ObjectId' was found" -InformationAction Continue
        }
    }
}

if ([string]::IsNullOrEmpty($objectName)) {
    Throw "ERROR --- No SPN, AD Group or AD User found corresponding to Object Id '$ObjectId'. Stop execution."
}

if (![string]::IsNullOrEmpty($ObjectId)) {

    $policies = $keyVault.AccessPolicies | Where-Object ObjectId -EQ $ObjectId
    if (-not $policies) {
        Set-DefaultKeyVaultAccessPolicy `
            -KeyVaultName $KeyVaultName `
            -ObjectId $ObjectId `
            -ObjectName $objectName `
            -ResourceGroupName $ResourceGroupName
    }
    else {
        $permissionsToCertificates = Merge-DefaultPermission -Permissions $policies.PermissionsToCertificates -PermissionType 'Certificates'
        $permissionsToKeys = Merge-DefaultPermission -Permissions $policies.PermissionsToKeys -PermissionType 'Keys'
        $permissionsToSecrets = Merge-DefaultPermission -Permissions $policies.PermissionsToSecrets -PermissionType 'Secrets'

        Write-Information -MessageData "INFO --- Merge permissions for Service Principal '$objectName' to Key Vault '$($keyVault.VaultName)'." -InformationAction Continue
        Set-AzKeyVaultAccessPolicy `
            -InputObject $keyVault `
            -ObjectId $ObjectId `
            -PermissionsToCertificates $permissionsToCertificates `
            -PermissionsToKeys $permissionsToKeys `
            -PermissionsToSecrets $permissionsToSecrets
    }
}

Write-Information -MessageData "INFO --- End script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue