[CmdletBinding()]
Param
(
    [Parameter(Mandatory = $true)]
    [ValidateLength(3, 24)]
    [ValidatePattern('^[a-zA-Z0-9-]+$')]
    [string]
    $KeyVaultName,

    [Parameter(Mandatory = $true)]
    [ValidateLength(1, 90)]
    [ValidatePattern('^[-\w\._\(\)]+$')]
    [string]
    $ResourceGroupName
)

function Remove-EventGridSystemTopic {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $KeyVaultName,

        [Parameter(Mandatory = $true)]
        [string]
        $ResourceGroupName
    )

    $context = Get-AzContext
    $topicName = "$KeyVaultName-evgt"
    $url = "https://management.azure.com/subscriptions/$($context.Subscription.Id)/resourceGroups/$ResourceGroupName/providers/Microsoft.EventGrid/systemTopics/$($topicName)?api-version=2021-12-01"

    Write-Information -MessageData "INFO --- Removing Event Grid System Topic '$topicName'." -InformationAction Continue
    $accessToken = Get-CccAccessToken `
        -Credential (Get-CccServiceAccount).Credential `
        -Resource 'https://management.core.windows.net' `
        -TenantId $context.Tenant.Id

    $headers = @{
        Authorization = "Bearer $accessToken"
    }

    try {
        $topic = Invoke-RestMethod -Headers $headers -Method 'Get' -Uri $url -UseBasicParsing
    }
    catch {
        if ($_.Exception.Response.StatusCode -ne [System.Net.HttpStatusCode]::NotFound) {
            throw
        }
    }

    if ($topic) {
        Remove-CccResourceLocks `
            -ResourceGroupName $ResourceGroupName `
            -ResourceName $topicName `
            -ResourceType 'Microsoft.EventGrid/systemTopics' | Out-Null

        Invoke-RestMethod -Headers $headers -Method 'Delete' -Uri $url -UseBasicParsing | Out-Null
    }
    else {
        Write-Information -MessageData "INFO --- Event Grid System Topic '$topicName' not found in Resource Group '$ResourceGroupName'." -InformationAction Continue
    }
}

Write-Information -MessageData "INFO --- Start script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue

# In case of an error, display the error message and stop executing
$ErrorActionPreference = 'Stop'

# Verify Resource Group existence and get properties
$resourceGroup = Get-CccResourceGroup -Name $ResourceGroupName
$ResourceGroupName = $resourceGroup.ResourceGroupName

$keyVault = Get-AzKeyVault -VaultName $KeyVaultName -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue
if ($keyVault) {
    Remove-CccResourceLocks `
        -ResourceGroupName $ResourceGroupName `
        -ResourceName $KeyVaultName `
        -ResourceType 'Microsoft.KeyVault/vaults' | Out-Null

    Write-Information -MessageData "INFO --- Removing Key Vault '$KeyVaultName'." -InformationAction Continue
    Remove-AzKeyVault -VaultName $KeyVaultName -ResourceGroupName $ResourceGroupName -Force | Out-Null
    Write-Information -MessageData "INFO --- Successfully removed Key Vault '$KeyVaultName'." -InformationAction Continue
}
else {
    Write-Information -MessageData "INFO --- Key Vault '$KeyVaultName' not found in Resource Group '$ResourceGroupName'." -InformationAction Continue
}

Remove-EventGridSystemTopic -KeyVaultName $KeyVaultName -ResourceGroupName $ResourceGroupName

Write-Information -MessageData "INFO --- End script at $(Get-Date -Format 'dd-MM-yyyy HH:mm')." -InformationAction Continue