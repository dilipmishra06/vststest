function Set-DefaultKeyVaultAccessPolicy  {
    param(

        [Parameter(Mandatory = $true)]
        [ValidatePattern('^[a-zA-Z0-9-]+$')]
        [string]
        $KeyVaultName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ObjectId,

        [Parameter(Mandatory = $False)]
        [string]
        $ObjectName,

        [Parameter(Mandatory = $true)]
        [ValidatePattern('^$|^[-\w\._\(\)]{1,90}$')]
        $ResourceGroupName
    )

    if ([string]::IsNullOrEmpty($ObjectName)) {
        Write-Information -MessageData "INFO --- Set Key Vault access for object id '$ObjectId'" -InformationAction Continue
    }
    Else {
        Write-Information -MessageData "INFO --- Set Key Vault access for '$ObjectName'" -InformationAction Continue
    }
    try {
        Set-AzKeyVaultAccessPolicy -VaultName $KeyVaultName -ResourceGroupName $ResourceGroupName `
            -ObjectId $ObjectId `
            -PermissionsToKeys get, list, create, update, delete, backup, restore, import, decrypt, encrypt, unwrapKey, wrapKey, verify, sign, purge, recover `
            -PermissionsToSecrets get, list, set, delete, backup, restore, purge, recover `
            -PermissionsToCertificates get, list, update, create, import, purge, recover `
            -ErrorAction SilentlyContinue
    }
    catch {
        Write-Error "ERROR --- An error has occurred: '$_'. Continue execution." -ErrorAction Continue
    }
}

function Merge-DefaultPermission {
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet('Keys', 'Secrets', 'Certificates')]
        [string]
        $PermissionType,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [System.Collections.Generic.List[string]]
        $Permissions
    )
    switch ($PermissionType) {
        "Keys" {
            $defaultPermissions = "get, list, create, update, delete, backup, restore, import, decrypt, encrypt, unwrapKey, wrapKey, verify, sign, purge, recover"
        }
        "Secrets" {
            $defaultPermissions = "get, list, set, delete, backup, restore, purge, recover"
        }
        "Certificates" {
            $defaultPermissions = "get, list, update, create, import, purge, recover"
        }
    }

    foreach ($permission in ($defaultPermissions).Split(',').Trim()) {
        if ($Permissions -notcontains $permission) {
            $Permissions.Add($permission)
        }
    }
    return $Permissions
}