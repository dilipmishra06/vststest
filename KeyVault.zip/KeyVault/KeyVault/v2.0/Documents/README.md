# Azure Key Vault v2.1

 v2.1

## Latest changes against 2.0

We refactored version 2.0 to make use of common library functions and merged scripts and templates with the DevOps Key Vault scripts templates.
The Key Vault publishes Secret Near Expiry events to an Event Grid System Topic. This topic has a subscription which triggers the central
CCC key rotation function.

## Product

The Azure CCC engineered version 2.0 of the Azure service **Key Vault** is positioned as a customer facing solution.

## High level picture of deployment

The product **Azure Key Vault** consists of **1 ARM template** and **3 Scripts**.

When deploying the ARM template, following sequence of activites are trigerred:

1. Key Vault deployment
2. Lock the Key Vault to prevent accidental deletion
3. Event Grid System Topic deployment
4. Lock the Event Grid System Topic to prevent accidental deletion
5. Event Grid System Topic Event Subscription deployment

## Pipeline configuration

1. Resource Group deployment (optional)
2. Key Vault

## Pre-requisites

### Resources

There are multiple resources which the **Key Vault** depends on. These must exist or be created before a **Key Vault** can be deployed.

1. Resource Group (to deploy all resources in)
2. Active Directory security group/User/SPN (will be added to the access policy settings of KV)

### Parameters New-KeyVault.ps1

Provisioning a new **Key Vault**:

- **EnabledForDeployment**: Specifies whether Azure Resource Manager is permitted to retrieve secrets from the key vault. Allowed values are true or false.
- **EnabledForDiskEncryption**: Enable access to Azure Disk Encryption for volumne encryption.Allowed values are true or false.
- **EnabledForTemplateDeployment**: Enable access to Azure Virtual Machine for deplyoment.Allowed values are true or false.
- **KeyVaultNamePrefix**: Provide the prefix for the name of the Key Vault based on your solution name. Min 3 maximum 12 characters long.
- **Location**: Location for Key Vault. Allowed values are North Europe, West Europe, UK South, UK west, and empty string.
- **ObjectId**: Object ID of the service principal who gets default access to the Key Vault.
- **ResourceGroupName**: Optional name of the Resource Group for all resources.
- **Sku**: Provide the SKU for KeyVault. Allowed values are Standard or Premium.
- **TemplateFile**: Path of the keyvault.json ARM template file.

### Parameters Update-KeyVault.ps1

Updating an existing **Key Vault**:

- **KeyVaultName**: Name of the Key Vault to update.
- **ObjectId**: Object ID of the service principal who gets default access to the Key Vault.
- **ResourceGroupName**: Optional name of the Resource Group where the Key Vault is located.

## Azure Resources

Solution design document located in SharePoint.

## Cleaning up the environment

There is 1 PowerShell script for cleaning up.

### Parameters Remove-KeyVault.ps1

- **KeyVaultName**: The name of the Key Vault to remove.
- **ResourceGroupName**: Optional name of the Resource Group where the Key Vault is located.
